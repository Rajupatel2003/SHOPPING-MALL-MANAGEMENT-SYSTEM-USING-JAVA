package com.sriindu.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingMallShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
