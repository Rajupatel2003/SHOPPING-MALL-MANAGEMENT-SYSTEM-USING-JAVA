package com.si.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopingMallItemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopingMallItemApplication.class, args);
	}

}
